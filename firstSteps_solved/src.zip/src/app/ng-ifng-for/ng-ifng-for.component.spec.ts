import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgIfngForComponent } from './ng-ifng-for.component';

describe('NgIfngForComponent', () => {
  let component: NgIfngForComponent;
  let fixture: ComponentFixture<NgIfngForComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgIfngForComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgIfngForComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
