import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngIf-ngFor',
  templateUrl: './ng-ifng-for.component.html',
  styleUrls: ['./ng-ifng-for.component.css']
})
export class NgIfngForComponent implements OnInit {
  inDOM = true;

  
  superheroes = [
    { name: "batman",
      alterEgo: "bruce wayne",
      superpowers: ["genius intellect", "vast wealth", "indomitable will"]
    },
    { name: "sprocketman",
      alterEgo: "",
      superpowers: ["throws sprockets"]
    },
    { name: "wonder woman",
      alterEgo: "Princess Diana of Themyscira",
      superpowers: ["superhuman strength", "fly", "uses boomerang tiara"]
    },
    { name: "northstar",
      alterEgo: "Jean-Paul Beaubier",
      superpowers: ["superhuman speed", "fly", "project photonic blasts"]
    },
    { name: "superlopez",
      alterEgo: "Juan López Fernández",
      superpowers: ["superhuman strength", "flight", "X-ray vision"]
    }
  ];

  constructor() { }

  ngOnInit() {
  }

  toggle(){
    this.inDOM = !this.inDOM;
  }

}
