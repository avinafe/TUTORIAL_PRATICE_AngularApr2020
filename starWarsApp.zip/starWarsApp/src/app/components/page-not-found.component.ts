import { Component, OnInit } from '@angular/core';


@Component({
  template: '<h2>Oooooops page not found'
})
export class PageNotFoundComponent {}
  
