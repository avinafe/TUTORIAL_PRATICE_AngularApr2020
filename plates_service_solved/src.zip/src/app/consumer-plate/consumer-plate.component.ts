import { Component, OnInit } from '@angular/core';
import { LicencePlateAuthorizationService } from '../licencePlateAuthorization.service';

@Component({
  selector: 'app-consumer-plate',
  templateUrl: './consumer-plate.component.html',
  styleUrls: ['./consumer-plate.component.css']
})
export class ConsumerPlateComponent implements OnInit {
  messageToShow: string;
  plateNumber: string;
  constructor(private plateAuthorSrv:LicencePlateAuthorizationService) { }
  ngOnInit() {
  }
  show(){
   this.plateAuthorSrv.authorize(this.plateNumber)
    .then(
       data =>{ this.messageToShow = "Congratulations!!! " + data},
       data =>{ this.messageToShow = "Sorry " + data });         
         
  }



}
