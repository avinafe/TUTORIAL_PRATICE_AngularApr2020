import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumerPlateComponent } from './consumer-plate.component';

describe('ConsumerPlateComponent', () => {
  let component: ConsumerPlateComponent;
  let fixture: ComponentFixture<ConsumerPlateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsumerPlateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsumerPlateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
