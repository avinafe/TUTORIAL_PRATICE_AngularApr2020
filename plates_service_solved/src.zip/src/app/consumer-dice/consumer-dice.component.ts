import { Component, OnInit } from '@angular/core';
import { DiceService } from '../dice.service';

@Component({
  selector: 'app-consumer-dice',
  template: '<h1>consumerDice says: {{throwResult}}</h1>'
})
export class ConsumerDiceComponent implements OnInit {

  throwResult: number;

  constructor( private diceSrv: DiceService ) { }

  ngOnInit() {
    this.throwResult = this.diceSrv.throwDice();
  }
}
