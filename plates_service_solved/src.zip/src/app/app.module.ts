import { BrowserModule } from '@angular/platform-browser';
import { NgModule  } from '@angular/core';
import { FormsModule } from '@angular/forms';

import {DiceService  } from "./dice.service";

import { AppComponent } from './app.component';
import { ConsumerDiceComponent } from './consumer-dice/consumer-dice.component';


import { LicencePlateAuthorizationService } from './licencePlateAuthorization.service';
import { ConsumerPlateComponent } from './consumer-plate/consumer-plate.component';
import { ConsumerDiceComponentLevelComponent } from './consumer-dice-component-level/consumer-dice-component-level.component';
import { ConsumerDiceInjectorComponent } from './consumer-dice-injector/consumer-dice-injector.component';


@NgModule({
  declarations: [
    AppComponent,
    ConsumerDiceComponent,
    ConsumerPlateComponent,
    ConsumerDiceComponentLevelComponent,
    ConsumerDiceInjectorComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [ DiceService, LicencePlateAuthorizationService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
