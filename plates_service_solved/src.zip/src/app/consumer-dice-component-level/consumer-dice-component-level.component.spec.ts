import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumerDiceComponentLevelComponent } from './consumer-dice-component-level.component';

describe('ConsumerDiceComponentLevelComponent', () => {
  let component: ConsumerDiceComponentLevelComponent;
  let fixture: ComponentFixture<ConsumerDiceComponentLevelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsumerDiceComponentLevelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsumerDiceComponentLevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
