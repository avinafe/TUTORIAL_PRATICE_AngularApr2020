import { Component, OnInit } from '@angular/core';
import { DiceService } from '../dice.service';

@Component({
  selector: 'app-consumer-dice-component-level',
  template: '<h1>consumerDice component  level says: {{throwResult}}</h1>',
  providers: [ DiceService ]
})
export class ConsumerDiceComponentLevelComponent implements OnInit {

  throwResult: number;

  constructor( private diceSrv: DiceService ) { }

  ngOnInit() {
    this.throwResult = this.diceSrv.throwDice();
     }
}
