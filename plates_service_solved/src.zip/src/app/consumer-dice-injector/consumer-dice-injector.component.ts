import { Component, OnInit } from '@angular/core';
import { Injector } from '@angular/core';
import { DiceService } from '../dice.service';

@Component({
  selector: 'app-consumer-dice-injector',
  template: '<h1>consumerDice with explicit injector says: {{throwResult}}</h1>'
})
export class ConsumerDiceInjectorComponent implements OnInit {

  throwResult: number;
  diceSrv: DiceService;

  constructor( private injector: Injector) { }

  ngOnInit() {
    this.diceSrv = this.injector.get(DiceService);
    this.throwResult = this.diceSrv.throwDice();
  }
}
