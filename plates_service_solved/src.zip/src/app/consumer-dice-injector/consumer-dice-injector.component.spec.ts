import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumerDiceInjectorComponent } from './consumer-dice-injector.component';

describe('ConsumerDiceInjectorComponent', () => {
  let component: ConsumerDiceInjectorComponent;
  let fixture: ComponentFixture<ConsumerDiceInjectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsumerDiceInjectorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsumerDiceInjectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
